import { test } from 'node:test';
import assert from 'node:assert';
import { parseUsageResponse, normalizePercent } from '../usageParser';
import { formatCountdown, formatStatusBar, formatTooltip } from '../usageFormatter';

test('parser: valid response (nested session/weekly)', () => {
  const u = parseUsageResponse({
    session: { percent: 35, resetAt: '2026-09-01T12:00:00Z' },
    weekly: { percent: 0.5, resetAt: 1750000000 },
  });
  assert.strictEqual(u.sessionPercent, 35);
  assert.ok(u.sessionResetAt instanceof Date);
  assert.strictEqual(u.weeklyPercent, 50); // 0.5 → 50%
  assert.ok(u.weeklyResetAt instanceof Date);
});

test('parser: valid response (flat fields)', () => {
  const u = parseUsageResponse({
    sessionPercent: 95,
    sessionResetAt: '2026-09-01T12:00:00Z',
    weeklyPercent: 20,
    weeklyResetAt: '2026-09-02T12:00:00Z',
  });
  assert.strictEqual(u.sessionPercent, 95);
  assert.strictEqual(u.weeklyPercent, 20);
});

test('parser: missing fields → null', () => {
  const u = parseUsageResponse({});
  assert.strictEqual(u.sessionPercent, null);
  assert.strictEqual(u.sessionResetAt, null);
  assert.strictEqual(u.weeklyPercent, null);
  assert.strictEqual(u.weeklyResetAt, null);
});

test('parser: malformed response (null/string/array) → nulls, no throw', () => {
  assert.doesNotThrow(() => parseUsageResponse(null));
  assert.doesNotThrow(() => parseUsageResponse('garbage'));
  assert.doesNotThrow(() => parseUsageResponse([1, 2, 3]));
  const u = parseUsageResponse('garbage');
  assert.strictEqual(u.sessionPercent, null);
});

test('normalizePercent: 0..1 → 0..100', () => {
  assert.strictEqual(normalizePercent(0.5), 50);
  assert.strictEqual(normalizePercent(1), 100);
  assert.strictEqual(normalizePercent(0), 0);
  assert.strictEqual(normalizePercent(35), 35);
});

test('countdown: 0s', () => {
  const now = 1000000;
  assert.strictEqual(formatCountdown(new Date(now), now), '0s');
});

test('countdown: 59s', () => {
  const now = 1000000;
  assert.strictEqual(formatCountdown(new Date(now + 59 * 1000), now), '59s');
});

test('countdown: 1m', () => {
  const now = 1000000;
  assert.strictEqual(formatCountdown(new Date(now + 60 * 1000), now), '1m');
});

test('countdown: 59m', () => {
  const now = 1000000;
  assert.strictEqual(formatCountdown(new Date(now + 59 * 60 * 1000), now), '59m');
});

test('countdown: 1h', () => {
  const now = 1000000;
  assert.strictEqual(formatCountdown(new Date(now + 60 * 60 * 1000), now), '1h');
});

test('countdown: 23h', () => {
  const now = 1000000;
  assert.strictEqual(formatCountdown(new Date(now + 23 * 60 * 60 * 1000), now), '23h');
});

test('countdown: 24h → 1d 0h', () => {
  const now = 1000000;
  assert.strictEqual(formatCountdown(new Date(now + 24 * 60 * 60 * 1000), now), '1d 0h');
});

test('countdown: multi-day', () => {
  const now = 1000000;
  assert.strictEqual(formatCountdown(new Date(now + (2 * 24 + 5) * 60 * 60 * 1000), now), '2d 5h');
});

test('countdown: null → —', () => {
  assert.strictEqual(formatCountdown(null), '—');
});

test('statusBar: ok format', () => {
  const u = { sessionPercent: 35, sessionResetAt: new Date(Date.now() + 3 * 3600 * 1000), weeklyPercent: null, weeklyResetAt: null };
  assert.match(formatStatusBar(u, true), /^🦙 35% 3h$/);
});

test('statusBar: no usage → 🦙 —', () => {
  assert.strictEqual(formatStatusBar(null, true), '🦙 —');
});

test('statusBar: no emoji', () => {
  const u = { sessionPercent: 35, sessionResetAt: null, weeklyPercent: null, weeklyResetAt: null };
  assert.strictEqual(formatStatusBar(u, false), '35% —');
});

test('tooltip: contains session and weekly', () => {
  const u = { sessionPercent: 35, sessionResetAt: new Date(Date.now() + 3600 * 1000), weeklyPercent: 20, weeklyResetAt: new Date(Date.now() + 24 * 3600 * 1000) };
  const t = formatTooltip(u);
  assert.match(t, /Session: 35%/);
  assert.match(t, /Weekly: 20%/);
});
