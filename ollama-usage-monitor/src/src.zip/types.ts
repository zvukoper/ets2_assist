/**
 * Внутренняя нормализованная модель usage (не привязана к сырому JSON API).
 */
export interface UsageInfo {
  sessionPercent: number | null;
  sessionResetAt: Date | null;
  weeklyPercent: number | null;
  weeklyResetAt: Date | null;
}

/** Состояние статус-бара. */
export type StatusState =
  | { kind: 'ok'; usage: UsageInfo }
  | { kind: 'no-key' }
  | { kind: 'error'; message: string };
