import { UsageInfo } from './types';

/**
 * Парсер ответа /api/usage.
 *
 * Точная структура ответа не документирована, поэтому парсер адаптивный:
 * принимает несколько возможных имён полей (session/weekly, percent/reset,
 * resetAt/reset_at, nextReset и т.п.) и нормализует их во внутреннюю модель.
 * Неизвестные поля игнорируются; отсутствующие → null. Никогда не бросает.
 */
export function parseUsageResponse(raw: unknown): UsageInfo {
  const out: UsageInfo = {
    sessionPercent: null,
    sessionResetAt: null,
    weeklyPercent: null,
    weeklyResetAt: null,
  };

  if (typeof raw !== 'object' || raw === null) return out;

  const root = raw as Record<string, unknown>;

  // Плоская структура: { session: {...}, weekly: {...} } ИЛИ { sessionPercent, ... }.
  const session = pickObject(root, ['session', 'sessionUsage', 'session_usage']);
  const weekly = pickObject(root, ['weekly', 'weeklyUsage', 'weekly_usage']);

  if (session) {
    out.sessionPercent = pickPercent(session);
    out.sessionResetAt = pickDate(session);
  } else {
    out.sessionPercent = pickPercent(root, ['sessionPercent', 'session_percent', 'session']);
    out.sessionResetAt = pickDate(root, ['sessionResetAt', 'session_reset_at', 'sessionReset']);
  }

  if (weekly) {
    out.weeklyPercent = pickPercent(weekly);
    out.weeklyResetAt = pickDate(weekly);
  } else {
    out.weeklyPercent = pickPercent(root, ['weeklyPercent', 'weekly_percent', 'weekly']);
    out.weeklyResetAt = pickDate(root, ['weeklyResetAt', 'weekly_reset_at', 'weeklyReset']);
  }

  return out;
}

function pickObject(obj: Record<string, unknown>, keys: string[]): Record<string, unknown> | null {
  for (const k of keys) {
    const v = obj[k];
    if (typeof v === 'object' && v !== null) return v as Record<string, unknown>;
  }
  return null;
}

function pickPercent(obj: Record<string, unknown>, keys?: string[]): number | null {
  const candidates = keys ?? ['percent', 'usagePercent', 'usage_percent', 'used', 'usedPercent', 'used_percent', 'value'];
  for (const k of candidates) {
    const v = obj[k];
    if (typeof v === 'number' && Number.isFinite(v)) return normalizePercent(v);
    if (typeof v === 'string') {
      const n = parseFloat(v);
      if (Number.isFinite(n)) return normalizePercent(n);
    }
  }
  return null;
}

function pickDate(obj: Record<string, unknown>, keys?: string[]): Date | null {
  const candidates = keys ?? ['resetAt', 'reset_at', 'reset', 'nextReset', 'next_reset', 'resetTime', 'reset_time', 'expiresAt', 'expires_at'];
  for (const k of candidates) {
    const v = obj[k];
    if (typeof v === 'number' && Number.isFinite(v)) {
      // Unix-секунды или миллисекунды.
      const ms = v > 1e12 ? v : v * 1000;
      const d = new Date(ms);
      if (!Number.isNaN(d.getTime())) return d;
    }
    if (typeof v === 'string') {
      const d = new Date(v);
      if (!Number.isNaN(d.getTime())) return d;
    }
  }
  return null;
}

/** Нормализация процента: 0..100 (если пришло 0..1 — умножаем на 100). */
export function normalizePercent(v: number): number {
  if (v >= 0 && v <= 1) return Math.round(v * 100);
  return Math.round(v);
}
