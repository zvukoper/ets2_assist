import * as vscode from 'vscode';
import { OllamaUsageClient } from './ollamaUsageClient';
import { StatusBar } from './statusBar';
import { UsageInfo, StatusState } from './types';

const API_KEY_SECRET = 'ollamaUsage.apiKey';

/**
 * Точка входа extension.
 * - StatusBarItem (справа, высокий приоритет, клик → settings).
 * - Polling каждые refreshInterval сек (мин 15).
 * - API key: env OLLAMA_API_KEY (read-only) → SecretStorage (fallback).
 * - Команды: refresh, setApiKey, openSettings.
 */
export function activate(context: vscode.ExtensionContext): void {
  const getConfig = () => vscode.workspace.getConfiguration('ollamaUsage');

  const getApiKey = (): string | undefined => {
    const envKey = process.env.OLLAMA_API_KEY;
    if (envKey && envKey.trim().length > 0) return envKey.trim();
    return context.secrets.get(API_KEY_SECRET) as unknown as string | undefined;
  };

  const client = new OllamaUsageClient(getApiKey);
  const statusBar = new StatusBar(() => getConfig().get<boolean>('showEmoji', true));

  let inFlight = false;
  let timer: NodeJS.Timeout | undefined;
  let disposed = false;

  const refresh = async (): Promise<void> => {
    if (inFlight) return; // исключить параллельные запросы
    inFlight = true;
    try {
      const key = getApiKey();
      if (!key) {
        statusBar.update({ kind: 'no-key' });
        return;
      }
      const usage: UsageInfo = await client.fetchUsage();
      statusBar.update({ kind: 'ok', usage });
    } catch (e) {
      const msg = e instanceof Error ? e.message : String(e);
      statusBar.update({ kind: 'error', message: msg });
    } finally {
      inFlight = false;
    }
  };

  const schedule = (): void => {
    if (timer) clearInterval(timer);
    const interval = Math.max(15, getConfig().get<number>('refreshInterval', 60));
    timer = setInterval(() => {
      if (!disposed && getConfig().get<boolean>('enabled', true)) void refresh();
    }, interval * 1000);
  };

  const setApiKey = async (): Promise<void> => {
    const value = await vscode.window.showInputBox({
      prompt: 'Enter Ollama API key',
      password: true,
      ignoreFocusOut: true,
    });
    if (value === undefined) return; // отменено
    const trimmed = value.trim();
    if (trimmed.length === 0) {
      await context.secrets.delete(API_KEY_SECRET);
      vscode.window.showInformationMessage('Ollama API key cleared.');
    } else {
      await context.secrets.store(API_KEY_SECRET, trimmed);
      vscode.window.showInformationMessage('Ollama API key saved.');
    }
    void refresh();
  };

  const openSettings = (): void => {
    void vscode.env.openExternal(vscode.Uri.parse('https://ollama.com/settings'));
  };

  context.subscriptions.push(
    statusBar,
    vscode.commands.registerCommand('ollamaUsage.refresh', () => void refresh()),
    vscode.commands.registerCommand('ollamaUsage.setApiKey', () => void setApiKey()),
    vscode.commands.registerCommand('ollamaUsage.openSettings', () => openSettings()),
    vscode.workspace.onDidChangeConfiguration((e) => {
      if (e.affectsConfiguration('ollamaUsage')) {
        schedule();
        void refresh();
      }
    }),
    { dispose: () => { disposed = true; if (timer) clearInterval(timer); } }
  );

  // Первый запрос сразу после activation + планирование.
  if (getConfig().get<boolean>('enabled', true)) {
    void refresh();
  }
  schedule();
}

export function deactivate(): void {
  // Таймер очищается через subscription { dispose } выше.
}
