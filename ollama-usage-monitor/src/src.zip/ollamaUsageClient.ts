import * as https from 'https';
import { UsageInfo } from './types';
import { parseUsageResponse } from './usageParser';

/**
 * HTTP-клиент к https://ollama.com/api/usage.
 * Использует встроенный Node https (без лишних зависимостей, без webview).
 */
export class OllamaUsageClient {
  private readonly baseUrl = 'https://ollama.com/api/usage';
  private readonly timeoutMs = 10000;

  constructor(private readonly getApiKey: () => string | undefined) {}

  /** Выполняет GET /api/usage и возвращает нормализованный UsageInfo. */
  fetchUsage(): Promise<UsageInfo> {
    const key = this.getApiKey();
    if (!key) {
      return Promise.reject(new Error('NO_API_KEY'));
    }

    return new Promise<UsageInfo>((resolve, reject) => {
      const req = https.get(
        this.baseUrl,
        {
          headers: {
            Authorization: `Bearer ${key}`,
            Accept: 'application/json',
          },
          timeout: this.timeoutMs,
        },
        (res) => {
          const status = res.statusCode ?? 0;
          let body = '';
          res.setEncoding('utf8');
          res.on('data', (chunk: string) => {
            body += chunk;
          });
          res.on('end', () => {
            if (status < 200 || status >= 300) {
              reject(new Error(`HTTP ${status}`));
              return;
            }
            try {
              const parsed: unknown = JSON.parse(body);
              resolve(parseUsageResponse(parsed));
            } catch (e) {
              reject(new Error('Invalid JSON'));
            }
          });
        }
      );
      req.on('timeout', () => {
        req.destroy(new Error('Timeout'));
      });
      req.on('error', (e) => {
        reject(e);
      });
    });
  }
}
