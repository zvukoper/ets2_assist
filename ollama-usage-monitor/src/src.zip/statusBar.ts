import * as vscode from 'vscode';
import { UsageInfo, StatusState } from './types';
import { formatStatusBar, formatTooltip } from './usageFormatter';

/**
 * Управление StatusBarItem: текст, tooltip, цвет (ThemeColor), команда по клику.
 * Не меняет глобальный цвет Status Bar.
 */
export class StatusBar {
  private readonly item: vscode.StatusBarItem;
  private readonly showEmoji: () => boolean;

  constructor(showEmoji: () => boolean) {
    this.showEmoji = showEmoji;
    this.item = vscode.window.createStatusBarItem(vscode.StatusBarAlignment.Right, 100);
    this.item.command = 'ollamaUsage.openSettings';
    this.item.tooltip = 'Ollama Cloud Usage';
    this.item.show();
  }

  update(state: StatusState): void {
    if (state.kind === 'ok') {
      const usage = state.usage;
      this.item.text = formatStatusBar(usage, this.showEmoji());
      this.item.tooltip = formatTooltip(usage);
      this.item.color = this.colorFor(usage.sessionPercent);
    } else if (state.kind === 'no-key') {
      this.item.text = this.showEmoji() ? '🦙 —' : '—';
      this.item.tooltip = 'Ollama Cloud Usage\n\nNo API key. Run "Ollama Usage: Set API Key".';
      this.item.color = new vscode.ThemeColor('statusBarItem.warningForeground');
    } else {
      this.item.text = this.showEmoji() ? '🦙 ?' : '?';
      this.item.tooltip = `Ollama Cloud Usage\n\nError: ${state.message}`;
      this.item.color = new vscode.ThemeColor('statusBarItem.errorForeground');
    }
  }

  dispose(): void {
    this.item.dispose();
  }

  /** Цвет по диапазону: <50 normal, 50-79 warning, >=80 error. */
  private colorFor(pct: number | null): vscode.ThemeColor | undefined {
    if (pct === null) return undefined;
    if (pct >= 80) return new vscode.ThemeColor('statusBarItem.errorForeground');
    if (pct >= 50) return new vscode.ThemeColor('statusBarItem.warningForeground');
    return undefined; // default
  }
}
