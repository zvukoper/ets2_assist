import { UsageInfo } from './types';

/**
 * Форматирование countdown до reset.
 * 0–59s → "Xs"; 1–59m → "Xm"; 1–23h → "Xh"; >=24h → "Xd Xh".
 * Секунды не показываем для нормального состояния (>=1m).
 */
export function formatCountdown(resetAt: Date | null, now: number = Date.now()): string {
  if (!resetAt) return '—';
  const diffMs = resetAt.getTime() - now;
  if (diffMs <= 0) return '0s';
  const totalSec = Math.floor(diffMs / 1000);
  if (totalSec < 60) return `${totalSec}s`;
  const totalMin = Math.floor(totalSec / 60);
  if (totalMin < 60) return `${totalMin}m`;
  const totalH = Math.floor(totalMin / 60);
  if (totalH < 24) return `${totalH}h`;
  const days = Math.floor(totalH / 24);
  const hours = totalH % 24;
  return `${days}d ${hours}h`;
}

/** Основной текст статус-бара: "🦙 35% 3h" / "🦙 —" / "🦙 ?". */
export function formatStatusBar(usage: UsageInfo | null, showEmoji: boolean): string {
  const prefix = showEmoji ? '🦙 ' : '';
  if (!usage) return `${prefix}—`;
  const pct = usage.sessionPercent;
  if (pct === null) return `${prefix}—`;
  const cd = formatCountdown(usage.sessionResetAt);
  return `${prefix}${pct}% ${cd}`;
}

/** Tooltip: Session + Weekly. */
export function formatTooltip(usage: UsageInfo | null): string {
  if (!usage) return 'Ollama Cloud Usage\n\nNo data.';
  const sPct = usage.sessionPercent === null ? '—' : `${usage.sessionPercent}%`;
  const sCd = formatCountdown(usage.sessionResetAt);
  const wPct = usage.weeklyPercent === null ? '—' : `${usage.weeklyPercent}%`;
  const wCd = formatCountdown(usage.weeklyResetAt);
  return `Ollama Cloud Usage\n\nSession: ${sPct}\nReset: ${sCd}\n\nWeekly: ${wPct}\nReset: ${wCd}`;
}
